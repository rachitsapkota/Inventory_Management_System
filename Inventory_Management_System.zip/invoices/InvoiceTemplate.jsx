import { Page, Text, View, Document } from '@react-pdf/renderer';
export const Invoice = ()=><Document><Page><Text>Invoice</Text></Page></Document>;